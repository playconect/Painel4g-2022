<?php
include("conexao.php");
include_once("functions.php");
global $banco;
$SQLUser = "SELECT * FROM login WHERE NULLIF(expiredate, '') IS NOT NULL";
$SQLUser = $banco->prepare($SQLUser);
$SQLUser->execute();
while($LnUser = $SQLUser->fetch()){									
	$DataExpirar = date('d/m/Y H:i:s', $LnUser['expiredate']);
	$DataAtual = date('d/m/Y H:i:s');
	$DataExpirarDia = $LnUser['expiredate'];
	$DataAtualDia = time();									
	if( ($DataExpirar == $DataAtual) || ($DataExpirar != $DataAtual) && ($DataAtualDia > $DataExpirarDia) ){
		$SQLUserDel = "DELETE FROM login WHERE id = ".$LnUser['id'];
		$SQLUserDel = $banco->prepare($SQLUserDel);
		$SQLUserDel->execute();
	}
}
?>